from .Unit_module import Unit_class
class Knight_class(Unit_class):
    name = "Knight"
    ability_value = 0.5
    ability = f"Hits all enemy squad by {ability_value * 100}% of own attack"