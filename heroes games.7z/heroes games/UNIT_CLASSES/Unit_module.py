
class Unit_class():
        name = ""
        health = 100
        attack = 20
        defence = 5
        life_status = True

        ability = ""
        ability_value = 0
        ability_cooldown = 3

        def unit_info(self):
                return f"{self.name}, health - {self.health}, attack - {self.attack}, defence - {self.defence}, ability - {self.ability}"

        def one(self):
                return "1"
ds = Unit_class()
print(ds.one())
print(ds.unit_info())









