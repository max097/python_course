from .Unit_module import Unit_class
class Shaman_class(Unit_class):
    name = "Shaman"
    ability_value = 10
    ability = f"Poison all enemy units for next 2 moves by {ability_value} health points"