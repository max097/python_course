from .Unit_module import Unit_class
class Archer_class(Unit_class):
    name = "Archer"
    ability = "triple hit to 1 enemy unit"
