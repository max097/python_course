from .Unit_module import Unit_class
class Wizard_class(Unit_class):
    name = "Wizard"
    ability = "Creates shield for all alies to protect them from 1 enemy attack"


