from .Unit_module import Unit_class
class Barbarian_class(Unit_class):
    name = "Barbarian"
    ability = "Stun all enemy units for the next move"