
from .Unit_module import Unit_class
class Healer_class(Unit_class):
    name = "Healer"
    ability_value = 50
    ability = f"Heal 1 teammate by {ability_value} health points"
    ability_cooldown = 2