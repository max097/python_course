import UNIT_CLASSES
import Texts_module

class Game_class():
    player_name = None
    player_gold = 1000
    arena_counter = 0
    all_arenas = 5
    player_alive_team = []
    player_dead_team = []
    win_status = None
    def game_continue(self):
        return True
    def play(self):
        #Познайомитись
        print(Texts_module.welcome_game_board())


        self.player_name = input(Texts_module.get_player_name())

        print(Texts_module.welcome_hero_name(self.player_name, self.all_arenas, self.player_gold))
        #Сформувати базову команду

        self.player_alive_team = [UNIT_CLASSES.Healer_class,
                                  UNIT_CLASSES.Wizard_class,
                                  UNIT_CLASSES.Shaman_class,
                                  UNIT_CLASSES.Archer_class]
        print(Texts_module.wow_you_have_a_squad(self.player_alive_team))
        #Познайомити з магазином
        #Основний цикл гри
        while self.game_continue():
            break
            #Створити арену, помістити туди команду гравця
            #По закінченню арени провести аналіз
            #Запросити в магазин
        #Аналіз закінчення гри
game = Game_class()
game.play()
