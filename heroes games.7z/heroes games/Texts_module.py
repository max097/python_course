import UNIT_CLASSES
def welcome_game_board():
    return '''
___________________________________________________________________________________________________

                    ********   GAME OF HEROES   ********
                     -- The game by Maksym Chornobuk --
___________________________________________________________________________________________________
'''

def get_player_name():
    return "Hello, Hero! What is your name? ---> "

def welcome_hero_name(player_name, all_arenas, player_gold):
    return f'''
    Welcome, my young hero {player_name}!
    Here is some money({player_gold}), you need to create your own squad and fight in {all_arenas} arenas
    Let's play the Game!
'''

def wow_you_have_a_squad(player_team):
    text = f"Wow! You have a squad from {len(player_team)} heroes!"
    for i in player_team:
        text += "\n"+ i.unit_info()
    return text